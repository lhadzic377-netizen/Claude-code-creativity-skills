#!/bin/bash
# Nexus Team Installer for OpenClaw

set -e

NEXUS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENTS_DIR="${HOME}/.openclaw/agents"

echo "Nexus Team Installer"
echo "===================="

# Check if OpenClaw agents directory exists
if [ ! -d "$AGENTS_DIR" ]; then
    echo "Creating OpenClaw agents directory..."
    mkdir -p "$AGENTS_DIR"
fi

# Copy all agents
echo "Installing agents..."
cp "$NEXUS_DIR"/agents/*.md "$AGENTS_DIR"/

echo ""
echo "Installed agents:"
ls -1 "$AGENTS_DIR"/*.md 2>/dev/null | xargs -n1 basename | sed 's/\.md$//' | while read agent; do
    echo "  - $agent"
done

echo ""
echo "Done! Start OpenClaw and load any agent."
echo ""
echo "Quick start: Load NEXUS first for any complex task."

# Nexus Team — 5-Agent Productivity System

A versatile 5-agent team for OpenClaw that handles any real-world task.

## The Team

| Agent | Role | Specialty |
|-------|------|-----------|
| **NEXUS** | Orchestrator | Task decomposition, coordination, synthesis |
| **ATLAS** | Analyst | Research, reasoning, pattern recognition |
| **FORGE** | Creator | Writing, building, generating any format |
| **LENS** | Reviewer | Quality, critique, verification |
| **GRID** | Executor | Commands, APIs, automation, real-world actions |

## How It Works

```
User → NEXUS (understands + breaks down task)
         ├── ATLAS (researches/analyzes)
         ├── FORGE (creates first draft)
         ├── GRID (executes actions)
         └── LENS (reviews everything)
         NEXUS (synthesizes + delivers)
```

Every agent is **versatile** — not tied to one domain or format. Handle emails, spreadsheets, code, research, reports, automation, and more with the same team.

## Install

```bash
# Run the install script
chmod +x install.sh && ./install.sh
```

## Manual Install

Copy the agent files to your OpenClaw agents directory:

```bash
cp -r agents/* ~/.openclaw/agents/
```

## Quick Start

```
1. Start OpenClaw gateway
2. Load any of the 5 agents
3. Start with NEXUS for any task
```

## Agent Details

**NEXUS** — The orchestrator. Start here for any complex task. It decomposes the work and coordinates the team.

**ATLAS** — Deep research and analysis. Ask it to investigate, compare, assess risks, or interpret data.

**FORGE** — Creation and generation. Ask it to write emails, draft reports, build scripts, create spreadsheets, or compose any document.

**LENS** — Quality review. Before sending or publishing anything important, route it through LENS for a pre-flight check.

**GRID** — Action and execution. Ask it to run commands, call APIs, automate workflows, or process files.

## Credits

Built for OpenClaw — modular AI agent platform.
